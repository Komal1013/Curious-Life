/*const ex = require('express');
const app = ex();
const bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient;
const connectionString = 'mongodb://127.0.0.1:27017';
app.use(ex.static('public'));
app.set('views', './views');
app.set('view engine', 'ejs')//template engine is ejs
// app.use(bodyParser.urlencoded({ extended: false }))
const urlencodedParser = bodyParser.urlencoded({ extended: false });
app.listen('2021', function () {
  console.log("listen on 2021");
});

MongoClient.connect(connectionString, { useUnifiedTopology: true })
  .then(client => {
    const db = client.db('clData');
    const clCollection = db.collection('bloglikes');
    app.get('/', (req, res) => {
     clCollection.find().toArray()
        .then(results => {
          res.render('homecl', { result: results })
        })
        .catch()
    })
    
    app.get('/blog', (req, res) => {
        
      
      clCollection.findOne({ "title": "Title 1" }, function (err, result) {
        console.log(result)
        
        res.render('blog', { result: result})
      })  
  })
  app.post('/blog',urlencodedParser, (req, res) => {
    console.log(res.length)
    clCollection.findOne({ "title": req.body.title }, function (err, result) {
      console.log(result)
     
      
      res.render('blog', { result: result})
      
    })
  })
  
    app.post('/blog',urlencodedParser, (req, res) => {
      
      var likenum = 0
      clCollection.findOne({ "title": req.body.title }, function (err, result) {
        console.log(result)
        likenum = result.like
        console.log(likenum)
        res.render('blog', { likes: likenum })
        clCollection.findOneAndUpdate(
          { "title": req.body.title },
          {
            $set: {
              like: ++likenum
            }
          },
          {
            upsert: true
          }
        )
          .then(result => {})
          .catch(error => console.error(error))
      })
      console.log(likenum, "likes")
      
    });

  })
  .catch(console.error) */