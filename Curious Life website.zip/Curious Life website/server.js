const ex = require('express');
const app = ex();
const bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient;
const connectionString = 'mongodb://127.0.0.1:27017';
const urlencodedParser = bodyParser.urlencoded({ extended: false });

const path = require("path")
app.use(ex.static(path.join(__dirname, 'public')));
app.set('views', './views');
app.set('view engine', 'ejs')//template engine is ejs
app.use(bodyParser.urlencoded({ extended: false }))
app.listen('2021', function () {
    console.log("listen on 2021");
});
MongoClient.connect(connectionString, { useUnifiedTopology: true })
    .then(client => {
        const db = client.db('clData');
        const clCollection = db.collection('bloglikes');
        app.get('/', (req, res) => {
            clCollection.find().toArray()
                .then(result => {
                    res.render('homecl', { result: result })
                })
                .catch()
        })
        // blog post
        app.get('/blog/:title', (req, res) => {
            const t = req.params.title
            console.log(t)
            clCollection.findOne({ "title": t }, (err, result) => {

                const rannum = Math.floor(Math.random() * 3) + 1;
                console.log(result, result.category)
                clCollection.find({ "category": result.category }).toArray()
                    .then(result2 => {
                        console.log(result2, "Hi")

                        res.render('blog', { result: result, result2: result2 })
                    })
                    .catch()
            })
        })
        app.post('/blog/:title', (req, res) => {
                const t = req.params.title;
                 console.log(t)
                 console.log(req.body.title)

                // Find the document that describes "lego"
                var a=++req.body.like;
                clCollection.findOneAndUpdate(
                    { "title":"Supreme Lord & The Creation" },
                    {
                      $set: {
                        like: a
                      }
                    },
                    {
                      upsert: false
                    }
                  )
                .then(updatedDocument =>{
                    console.log(updatedDocument,"liked")
                })
                .catch()
                console.log(a)

    })
})
