
function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }

    return "";
}

document.querySelector(".likebtn").addEventListener('click', () => {
    const title = document.querySelector(".blogtitle").innerHTML;
    var likenum = document.querySelector(".likeno").innerHTML;
    
    if (getCookie(title)) {
        alert("already liked")
    }
    else {
        // setCookie(, "1")
        // alert("liked")
        var title1=document.querySelector(".blogtitle").innerHTML.split(' ');
        title=title1[title1.length-1]
        console.log(title)
        $.post(`/blog/${title}`,  
        { 
            "title": `${title}`,
           "like": likenum
        })
        .done(function() {
            alert('Thanks for liking!');
            document.querySelector(".likebtn").style.color = "red";
            document.querySelector(".likebtn").style.backgroundColor = "red";
            document.querySelector(".likeno").innerHTML=++likenum;
        })
        .fail(function(jqxhr, settings, ex) { alert('failed, ' + ex); });
        alert('Thanks for liking!');
            document.querySelector(".likebtn").style.color = "red";
            document.querySelector(".likebtn").style.backgroundColor = "red";
            document.querySelector(".likeno").innerHTML=++likenum;
    }
})
function addStr(str, index, stringToAdd){
    return str.substring(0, index) + stringToAdd + str.substring(index, str.length);
  }
  // Siya Kabir break
  str = document.querySelector(".blog4 p").innerHTML;
str1=str.split('Tushar:');
str2="";
for(i=0;i<str1.length;i++){
    // if(i!=0)
        str2+="<br>Tushar: "+str1[i];
}
str1=str2.split('Komal:');
str2="";
for(i=0;i<str1.length;i++){
    // if(i!=0)
        str2+="<br>Komal: "+str1[i];
}
// if()
str2=str2.substring(25,str2.length);
document.querySelector(".blog4 p").innerHTML=str2

document.querySelector(".commentbtn").addEventListener('click',()=>{
    document.querySelector(".commentbox").style.display = 'block'
})
// Date editing
document.querySelector(".date").innerHTML=document.querySelector(".date").innerHTML.split('00:')[0];
// setInterval(()=>{if(screen.width<480){
//     document.querySelector(".editorlike col-md-4").className="";
//     document.querySelector(".editorlike col-md-8").className="";

// };},1000)
